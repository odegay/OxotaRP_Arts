#!/bin/bash

java -jar shoebill-updater.jar